package br.com.alunra.Screenmtach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenmtachApplicationTests {

	@Test
	void contextLoads() {
	}

}
