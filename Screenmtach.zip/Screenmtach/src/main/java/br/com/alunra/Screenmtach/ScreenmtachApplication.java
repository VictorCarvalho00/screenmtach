package br.com.alunra.Screenmtach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScreenmtachApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScreenmtachApplication.class, args);
	}

}
